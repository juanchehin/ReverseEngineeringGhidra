# CrackMes

Within this folder you will find four crackmes all sources from crackmes.one, the original authors will be credited below

1. kellek's noprelo: https://crackmes.one/crackme/5b9d312233c5d45fc286ae03
2. m3hd1's half-twins: https://crackmes.one/crackme/5dce805c33c5d419aa0131ae
3. crackmes.de's moreboredthanyou by stefanie: https://crackmes.one/crackme/5ab77f5a33c5d40ad448c504
4. BitFriends's auth: https://crackmes.one/crackme/5e8349b033c5d4439bb2e040


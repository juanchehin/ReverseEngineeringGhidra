# Session Four Exercises

These exercises are designed to illusrate the principals that are covered in the course materials, for session four we have the following exercises:

* ```crackmes.one``` - This folder contains 4 additional challenges for you to solve, in ascending difficulty
* ```script-exercises``` - This contains 3 different programs, with script exercises for you to perform and run on the various binaries
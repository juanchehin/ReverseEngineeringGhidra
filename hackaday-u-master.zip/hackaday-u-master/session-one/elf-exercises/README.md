# Elf Exercises

In this folder we have two ELF files, can you tell the differences between them?

1. What are the main differences between these two files?
2. How are these two files related?
3. Can they both be executed in the docker container? Why or why not?

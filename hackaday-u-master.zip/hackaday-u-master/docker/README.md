# Dockerfile Instructions

This Docker container can be used to run all of the exercises included in the hackaday-u course.

* [Install Docker](https://docs.docker.com/get-docker/)

* Build the container:
    * ```build . -t hackaday-u```

* Run the container:
    * ```docker  run --rm -it hackaday-u /bin/bash``` 
